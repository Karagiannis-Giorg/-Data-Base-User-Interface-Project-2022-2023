
import java.sql.*;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ΚΑΡΑΓΙΑΝΝΗΣ
 */
public class DBconnection {
    public static void main(String[] arguments){
    String data = "jdbc:mysql://localhost:3306/travel_agency";
    try(
         Connection conn = DriverManager.getConnection(data,"root","karagiannis");
         Statement st = conn.createStatement()) {
        
       Class.forName("com.mysql.jdbc.Driver");
       ResultSet rec = st.executeQuery( "select * " + "from travel_agency.worker");
       
       while (rec.next()){
       System.out.println("worker AT: " + rec.getString(1));
       System.out.println("worker name:" + rec.getString(2));
       System.out.println("worker last name: " + rec.getString(3));
       System.out.println("worker salary: " + rec.getString(4));
       System.out.println("worker br code: " + rec.getString(5));
       }
   
       st.close();
       
    }
    catch (SQLException s){
     System.out.println("SQL Error:"+ s.toString() + " " + s.getErrorCode() + " " + s.getSQLState());
    
    }
    
    catch (Exception e){
     System.out.println("Error:"+ e.toString() + e.getMessage());
    
    }
  }
}
